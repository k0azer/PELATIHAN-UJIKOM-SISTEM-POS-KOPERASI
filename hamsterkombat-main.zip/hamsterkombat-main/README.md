"# hamsterkombat" 
tutor dalam script

# PLEASE JANGAN REPORT LAGI